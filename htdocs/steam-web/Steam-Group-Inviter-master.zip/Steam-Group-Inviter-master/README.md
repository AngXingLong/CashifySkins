Steam-Group-Inviter
===================

Invite Steam users to your group with an automated backend script. 

HOW TO USE
===================

Provide info for Steam login as well as well as database storage. You can only place 100 invites per hour. 
